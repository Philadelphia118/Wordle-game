# wordle

A Pen created on CodePen.

Original URL: [https://codepen.io/Rebel-Plays/pen/yyJZdZP](https://codepen.io/Rebel-Plays/pen/yyJZdZP).

